def main():
    print("ciao")


if __name__ == '__main__':
    main()
