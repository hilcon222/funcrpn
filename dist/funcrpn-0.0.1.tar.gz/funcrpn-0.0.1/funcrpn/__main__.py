print("ciao")
